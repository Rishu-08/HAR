# HAR
Human Activity Recognition uses cnn and lstm to work on the videos which are sequential data to accurately predicts the activity being performed

This model was made using the UCF50 action recognition dataset
